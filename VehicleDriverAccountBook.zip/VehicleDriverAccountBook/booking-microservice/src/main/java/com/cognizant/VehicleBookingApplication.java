package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleBookingApplication {

    public static void main(String[] args) {

        SpringApplication.run(VehicleBookingApplication.class, args);
        System.out.println("Vehicle Booking Microservice Started.....");
    }

}
