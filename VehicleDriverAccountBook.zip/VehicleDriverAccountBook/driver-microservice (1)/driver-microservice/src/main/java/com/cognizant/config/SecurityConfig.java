package com.cognizant.config;

public class SecurityConfig {
}
