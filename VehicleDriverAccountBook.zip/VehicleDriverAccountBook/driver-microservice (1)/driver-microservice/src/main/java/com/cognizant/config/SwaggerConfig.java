package com.cognizant.config;

public class SwaggerConfig {
}
